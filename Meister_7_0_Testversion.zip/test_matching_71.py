import unittest,server
class Matching71(unittest.TestCase):
 def job(self,title,loc,desc='Remote'):
  return {'title':title,'location':loc,'description':desc,'company':'Test','source':'Test','url':'https://example.org/job','salary':'','date':'','id':''}
 def test_apj_not_recommended(self):
  x=server.assess(self.job('Manager, Sales Recruiting (APJ)','Remote, Australia; Remote, Singapore'))
  self.assertNotEqual(x['category'],'recommended');self.assertLessEqual(x['fit'],12)
 def test_us_not_recommended(self):
  x=server.assess(self.job('HR Coordinator','United States'))
  self.assertNotEqual(x['category'],'recommended')
 def test_german_worldwide_candidate(self):
  x=server.assess(self.job('Recruiting Coordinator German speaking','Worldwide','Fully remote, fluent German required.'))
  self.assertEqual(x['category'],'recommended')
 def test_german_unknown_review(self):
  x=server.assess(self.job('Recruiting Coordinator German speaking','Remote','Fluent German required.'))
  self.assertEqual(x['category'],'review')
 def test_english_downrank(self):
  x=server.assess(self.job('Recruiting Coordinator German speaking','Worldwide','Fluent German required. Fluent English required.'))
  self.assertNotEqual(x['category'],'recommended')
 def test_sales_excluded(self):
  x=server.assess(self.job('German customer support','Worldwide','Remote German required. Outbound sales and cold calling.'))
  self.assertEqual(x['category'],'excluded')
if __name__=='__main__':unittest.main()
